const addcomment=(bid)=>{
    console.log(bid);
    var comment={
        //userid:sessionStorage.getItem("userid"),
        //text:document.getElementById("txtcomment").value
        userid:sessionStorage.getItem("userid"),
        text:document.getElementById("txtcomment").value
    }

    /**
     * Get the comments of the selected blog
     */

    $.ajax({
        type: "GET",
        contentType: "application/json",
        url: `http://localhost:3000/blogs?id=${bid}`,
        dataType: "json",
        success: (blog) => {
            if (blog != null) {
                var {
                    userid ,
                    category ,
                    title,
                    imgpath,
                    text,
                    timestamp,
                    likes,
                    comments,
                    flag,
                    id
                } = blog[0];
                const commentarr = [...comments, comment];  //comments appended

                $.ajax({
                    type: 'PATCH',
                    contentType: 'application/json',
                    url: `http://localhost:3000/blogs/${bid}`,
                    data:JSON.stringify({comments:commentarr}),
                    dataType: "json",
                    success: (data)=>{
                        alert("Save Complete")
                        console.log(data);
                    }

                })

            }
        }
    })

}


